// Comprueba si un vídeo sigue disponible (y, en Pornhub, si se puede incrustar).
// Si no lo está, el navegador lo oculta del catálogo. Falla en abierto: ante cualquier
// duda (timeout, error de red, respuesta desconocida) responde ok:true para no
// ocultar vídeos que sí funcionan.
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const json = (ok: boolean, maxAge: number) =>
  new Response(JSON.stringify({ ok }), {
    headers: {
      "content-type": "application/json;charset=utf-8",
      "cache-control": `public, max-age=${maxAge}`,
    },
  });

async function pedir(url: string): Promise<{ status: number; data: any } | null> {
  try {
    const r = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" }, signal: AbortSignal.timeout(5000) });
    let data: any = null;
    try { data = await r.json(); } catch {}
    return { status: r.status, data };
  } catch {
    return null;
  }
}

// Respuestas tipo hubtraffic: {"active":{"video_id":"..","is_active":"1"}}
function estaActivo(d: any): boolean | null {
  const v = d?.active?.is_active ?? d?.is_active;
  if (v === undefined || v === null) return null;
  return !(v === false || v === 0 || v === "0" || String(v).toLowerCase() === "false");
}

async function pornhub(id: string) {
  const r = await pedir("https://www.pornhub.com/webmasters/video_embed_code?id=" + encodeURIComponent(id));
  if (!r || r.status >= 500) return json(true, 60);
  const d = r.data;
  if (typeof d?.embed?.code === "string" && d.embed.code.includes("iframe")) return json(true, 86400);
  // Error explícito de la API: no incrustable o eliminado.
  if (d && typeof d === "object" && (d.code || d.message) && !d.embed) return json(false, 86400);
  return json(true, 60);
}

async function hubtraffic(url: string) {
  const r = await pedir(url);
  if (!r || r.status >= 500) return json(true, 60);
  const activo = estaActivo(r.data);
  if (activo === false) return json(false, 86400);
  return json(true, activo === true ? 86400 : 60);
}

async function eporner(id: string) {
  const r = await pedir(`https://www.eporner.com/api/v2/video/id/?id=${encodeURIComponent(id)}&format=json`);
  if (!r || r.status >= 500) return json(true, 60);
  if (r.status === 404) return json(false, 86400);
  const d = r.data;
  if (d && typeof d === "object" && (d.id || d.title)) return json(true, 86400);
  if (d && typeof d === "object" && !Array.isArray(d) && Object.keys(d).length && !d.id && !d.title && (d.error || d.message)) return json(false, 86400);
  return json(true, 60);
}

export async function onRequestGet({ request }: any) {
  const url = new URL(request.url);
  const completo = url.searchParams.get("id") ?? "";
  const m = completo.match(/^(ph|yp|redtube|eporner)-([a-zA-Z0-9_-]{3,60})$/);
  if (!m) return json(true, 60);
  const [, tipo, id] = m;
  if (tipo === "ph") return pornhub(id);
  if (tipo === "yp") return hubtraffic("https://www.youporn.com/api/webmasters/is_video_active/?id=" + encodeURIComponent(id));
  if (tipo === "redtube") return hubtraffic("https://api.redtube.com/?data=redtube.Videos.isVideoActive&output=json&video_id=" + encodeURIComponent(id));
  return eporner(id);
}
