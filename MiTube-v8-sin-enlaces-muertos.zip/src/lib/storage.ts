import type { Video } from "@/types";

const FAV = "favoritos";
const HIST = "historial";

const leer = <T,>(k: string, def: T): T => {
  try {
    const r = localStorage.getItem(k);
    return r ? (JSON.parse(r) as T) : def;
  } catch {
    return def;
  }
};

const escribir = (k: string, v: unknown) => {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {}
};

export const listarFavoritos = () => leer<Video[]>(FAV, []);
export const esFavorito = (id: string) => listarFavoritos().some((v) => v.id === id);

export function toggleFavorito(v: Video) {
  const l = listarFavoritos();
  const i = l.findIndex((x) => x.id === v.id);
  if (i >= 0) l.splice(i, 1);
  else l.unshift(v);
  escribir(FAV, l);
  return i < 0;
}

export const listarHistorial = () => leer<(Video & { visto: number })[]>(HIST, []);

export function anadirHistorial(v: Video) {
  const l = listarHistorial().filter((x) => x.id !== v.id);
  l.unshift({ ...v, visto: Date.now() });
  escribir(HIST, l.slice(0, 50));
}

export const limpiarHistorial = () => escribir(HIST, []);
