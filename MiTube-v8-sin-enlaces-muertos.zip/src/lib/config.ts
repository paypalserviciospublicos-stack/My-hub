export const SITE_NAME = "MiTube";
export const CACHE_HORAS = 0.25;
export const REFRESCO_MIN = 5;
