import { useEffect, useRef, useState } from "react";
import { listar, type Filtro } from "@/lib/videos";
import type { Video } from "@/types";
import VideoCard from "./VideoCard";
import EmptyState from "./EmptyState";

export default function VideoGrid({ filtro, vacio = "No hay videos" }: { filtro: Filtro; vacio?: string }) {
  const [items, setItems] = useState<Video[]>([]);
  const [pagina, setPagina] = useState(1);
  const [hayMas, setHayMas] = useState(false);
  const [cargando, setCargando] = useState(true);
  const ref = useRef<HTMLDivElement>(null);
  const clave = JSON.stringify(filtro);

  useEffect(() => {
    setItems([]);
    setPagina(1);
  }, [clave]);

  useEffect(() => {
    let vivo = true;
    setCargando(true);
    listar({ ...filtro, pagina, porPagina: 24 }).then((r) => {
      if (!vivo) return;
      setItems((p) => (pagina === 1 ? r.items : [...p, ...r.items]));
      setHayMas(r.hayMas);
      setCargando(false);
    }).catch(() => {
      if (!vivo) return;
      setHayMas(false);
      setCargando(false);
    });
    return () => {
      vivo = false;
    };
  }, [clave, pagina]);

  useEffect(() => {
    const el = ref.current;
    if (!el || !hayMas) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting && !cargando) setPagina((p) => p + 1);
      },
      { rootMargin: "400px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [hayMas, cargando]);

  if (!cargando && items.length === 0) return <EmptyState titulo={vacio} />;

  return (
    <>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {items.map((v) => (
          <VideoCard key={v.id} video={v} />
        ))}
      </div>
      {cargando && (
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-[#14141c]" />
              <div className="mt-2 h-4 w-4/5 rounded bg-[#14141c]" />
            </div>
          ))}
        </div>
      )}
      <div ref={ref} className="h-8" />
    </>
  );
}
