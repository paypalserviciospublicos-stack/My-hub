import { Link } from "react-router-dom";

export default function TagPill({ etiqueta }: { etiqueta: string }) {
  return (
    <Link
      to={`/etiqueta/${etiqueta}`}
      className="rounded-full border border-[#24242f] px-3 py-1 text-xs text-[#b9b9c4] hover:border-[#ff2d78] hover:text-[#ff2d78]"
    >
      {etiqueta}
    </Link>
  );
}
