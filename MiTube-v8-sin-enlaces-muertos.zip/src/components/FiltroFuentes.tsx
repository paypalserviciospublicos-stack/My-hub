import { Link, useParams } from "react-router-dom";
import { FUENTES } from "@/data/fuentes";

export default function FiltroFuentes() {
  const { slug } = useParams();

  return (
    <div className="flex flex-wrap gap-2" aria-label="Filtrar por fuente">
      <Link
        to="/"
        className={`rounded-full px-3 py-1 text-xs ${
          !slug ? "bg-[#ff2d78] text-white" : "border border-[#24242f] text-[#b9b9c4] hover:text-white"
        }`}
      >
        Todo
      </Link>
      {FUENTES.map((f) => (
        <Link
          key={f.slug}
          to={`/fuente/${f.slug}`}
          className={`rounded-full px-3 py-1 text-xs ${
            slug === f.slug ? "text-black" : "border border-[#24242f] text-[#b9b9c4] hover:text-white"
          }`}
          style={slug === f.slug ? { background: f.color } : undefined}
        >
          {f.nombre}
        </Link>
      ))}
    </div>
  );
}
