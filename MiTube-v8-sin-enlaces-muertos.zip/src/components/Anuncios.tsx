import { useEffect } from "react";

export default function Anuncios() {
  useEffect(() => {
    const containerId = "container-55304d0b7ed5f1802470e7ad5504d8af";
    if (document.querySelector('script[data-biomanos-banner="true"]')) return;

    const script = document.createElement("script");
    script.async = true;
    script.setAttribute("data-cfasync", "false");
    script.dataset.biomanosBanner = "true";
    script.src = "https://biomanos.org/21/55304d0b7ed5f1802470e7ad5504d8af";

    const container = document.getElementById(containerId);
    if (container) container.appendChild(script);
  }, []);

  return (
    <div className="my-5 flex min-h-0 w-full justify-center overflow-hidden">
      <div id="container-55304d0b7ed5f1802470e7ad5504d8af" className="w-full max-w-full" />
    </div>
  );
}
