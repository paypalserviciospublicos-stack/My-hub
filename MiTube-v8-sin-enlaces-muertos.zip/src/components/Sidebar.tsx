import TagPill from "./TagPill";

const ESTILOS = [
  "anal", "blowjob", "creampie", "oral", "amateur", "lesbian", "milf", "mature",
  "interracial", "threesome", "deepthroat", "facial", "handjob", "solo", "couple",
  "massage", "roleplay", "cosplay", "japanese", "chinese", "korean", "russian",
  "asian", "latina", "ebony", "blonde", "brunette", "pov", "hd", "4k",
];

export default function Sidebar() {
  return (
    <aside className="hidden w-56 shrink-0 lg:block">
      <h2 className="mb-3 text-sm font-medium">Estilos populares</h2>
      <div className="flex flex-wrap gap-2">
        {ESTILOS.map((t) => <TagPill key={t} etiqueta={t} />)}
      </div>
    </aside>
  );
}
