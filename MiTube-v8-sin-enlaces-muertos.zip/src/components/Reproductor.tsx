import { useState } from "react";
import { Play } from "lucide-react";
import type { Video } from "@/types";

export default function Reproductor({ video, directo = false }: { video: Video; directo?: boolean }) {
  const [activo, setActivo] = useState(directo);

  if (video.video_url) {
    return (
      <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black">
        <video
          src={video.video_url}
          poster={video.miniatura || undefined}
          className="absolute inset-0 h-full w-full object-contain"
          controls
          loop
          playsInline
          preload="metadata"
        />
      </div>
    );
  }

  if (activo) {
    return (
      <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black">
        <iframe
          src={video.embed_url}
          title={video.titulo}
          className="absolute inset-0 h-full w-full"
          allowFullScreen
          allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
          referrerPolicy="strict-origin-when-cross-origin"
          sandbox="allow-scripts allow-same-origin allow-forms allow-presentation"
        />
      </div>
    );
  }

  return (
    <button
      onClick={() => setActivo(true)}
      className="group relative block aspect-video w-full overflow-hidden rounded-xl bg-black"
    >
      {video.miniatura ? (
        <img
          src={video.miniatura}
          alt={video.titulo}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={(e) => { e.currentTarget.style.display = "none"; }}
          className="h-full w-full object-cover opacity-80 transition group-hover:opacity-100"
        />
      ) : (
        <span className="absolute inset-0 bg-gradient-to-br from-[#24202b] via-[#15151d] to-[#0b0b0f]" />
      )}
      <span className="absolute inset-0 grid place-items-center">
        <span className="grid h-16 w-16 place-items-center rounded-full bg-[#ff2d78] text-white">
          <Play className="h-7 w-7 translate-x-0.5" />
        </span>
      </span>
    </button>
  );
}
