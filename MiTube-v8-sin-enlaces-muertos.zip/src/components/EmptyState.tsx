import { Film } from "lucide-react";

export default function EmptyState({ titulo, texto }: { titulo: string; texto?: string }) {
  return (
    <div className="grid place-items-center py-20 text-center">
      <Film className="h-10 w-10 text-[#8b8b96]" />
      <p className="mt-3 font-medium">{titulo}</p>
      {texto && <p className="mt-1 text-sm text-[#8b8b96]">{texto}</p>}
    </div>
  );
}
