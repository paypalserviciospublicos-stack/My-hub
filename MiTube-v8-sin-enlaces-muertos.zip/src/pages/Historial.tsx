import { useState } from "react";
import { Helmet } from "react-helmet-async";
import VideoCard from "@/components/VideoCard";
import EmptyState from "@/components/EmptyState";
import { limpiarHistorial, listarHistorial } from "@/lib/storage";

export default function Historial() {
  const [l, setL] = useState(listarHistorial);

  return (
    <>
      <Helmet>
        <title>Historial</title>
      </Helmet>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold">Historial</h1>
        {l.length > 0 && (
          <button
            onClick={() => {
              limpiarHistorial();
              setL([]);
            }}
            className="rounded-lg border border-[#24242f] px-3 py-1.5 text-sm text-[#b9b9c4] hover:text-white"
          >
            Limpiar
          </button>
        )}
      </div>
      {l.length === 0 ? (
        <EmptyState titulo="Historial vacio" />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {l.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      )}
    </>
  );
}
