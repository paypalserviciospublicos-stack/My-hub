import { Link } from "react-router-dom";

export default function NoEncontrado() {
  return (
    <div className="grid place-items-center py-24 text-center">
      <p className="text-4xl font-semibold">404</p>
      <p className="mt-2 text-[#8b8b96]">Esta pagina no existe.</p>
      <Link to="/" className="mt-4 rounded-lg bg-[#ff2d78] px-4 py-2 text-sm text-white">
        Volver al inicio
      </Link>
    </div>
  );
}
