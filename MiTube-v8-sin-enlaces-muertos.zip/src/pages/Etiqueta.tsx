import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import VideoGrid from "@/components/VideoGrid";

export default function Etiqueta() {
  const { slug = "" } = useParams();

  return (
    <>
      <Helmet>
        <title>Etiqueta: {slug}</title>
      </Helmet>
      <h1 className="mb-4 text-xl font-semibold">#{slug}</h1>
      <VideoGrid filtro={{ etiqueta: slug }} vacio={`No hay videos con la etiqueta ${slug}`} />
    </>
  );
}
