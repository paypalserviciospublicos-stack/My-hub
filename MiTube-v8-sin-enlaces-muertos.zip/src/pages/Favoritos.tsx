import { Helmet } from "react-helmet-async";
import VideoCard from "@/components/VideoCard";
import EmptyState from "@/components/EmptyState";
import { listarFavoritos } from "@/lib/storage";

export default function Favoritos() {
  const l = listarFavoritos();

  return (
    <>
      <Helmet>
        <title>Favoritos</title>
      </Helmet>
      <h1 className="mb-4 text-xl font-semibold">Favoritos</h1>
      {l.length === 0 ? (
        <EmptyState titulo="Aun no has guardado nada" texto="Pulsa el corazon en cualquier video." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {l.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      )}
    </>
  );
}
