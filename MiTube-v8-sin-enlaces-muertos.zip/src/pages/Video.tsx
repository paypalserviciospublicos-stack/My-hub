import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Eye, Heart } from "lucide-react";
import Reproductor from "@/components/Reproductor";
import VideoCard from "@/components/VideoCard";
import TagPill from "@/components/TagPill";
import { porId, relacionadas } from "@/lib/videos";
import { anadirHistorial, esFavorito, toggleFavorito } from "@/lib/storage";
import { fuentePorSlug } from "@/data/fuentes";
import { bloquear, esIncrustable } from "@/lib/bloqueados";
import type { Video as V } from "@/types";

export default function Video() {
  const { id = "" } = useParams();
  const [v, setV] = useState<V | null>(null);
  const [rel, setRel] = useState<V[]>([]);
  const [fav, setFav] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let vivo = true;
    setV(null);
    porId(id).then(async (x) => {
      if (!vivo || !x) return;
      const saltar = async () => {
        // No está disponible / no se puede reproducir aquí: se oculta del catálogo y se salta.
        bloquear(x.id);
        const sig = (await relacionadas(x, 12)).find((r) => r.id !== x.id);
        if (vivo) navigate(sig ? `/video/${sig.id}` : "/", { replace: true });
      };
      if (x.id.startsWith("ph-")) {
        // Pornhub: se comprueba antes de mostrar el reproductor para que no salga su cartel.
        if (!(await esIncrustable(x.id))) return saltar();
      } else {
        // Resto: el reproductor aparece al instante y la comprobación va en segundo plano.
        esIncrustable(x.id).then((ok) => { if (!ok && vivo) saltar(); });
      }
      if (!vivo) return;
      setV(x);
      setFav(esFavorito(x.id));
      anadirHistorial(x);
      setRel(await relacionadas(x, 12));
    });
    return () => {
      vivo = false;
    };
  }, [id, navigate]);

  if (!v) return <div className="py-20 text-center text-[#8b8b96]">Cargando...</div>;
  const f = fuentePorSlug(v.fuente);

  return (
    <>
      <Helmet>
        <title>{v.titulo}</title>
        <meta name="description" content={v.descripcion || v.titulo} />
      </Helmet>
      <div className="flex flex-col gap-8 lg:flex-row">
        <div className="min-w-0 flex-1">
          <Reproductor video={v} directo />
          <h1 className="mt-4 text-xl font-semibold">{v.titulo}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-[#8b8b96]">
            {f && (
              <Link to={`/fuente/${f.slug}`} style={{ color: f.color }} className="font-medium">
                {f.nombre}
              </Link>
            )}
            <span className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              {v.vistas.toLocaleString("es")}
            </span>
            <button
              onClick={() => setFav(toggleFavorito(v))}
              className="ml-auto flex items-center gap-1.5 rounded-lg border border-[#24242f] px-3 py-1.5 text-[#b9b9c4] hover:border-[#ff2d78] hover:text-[#ff2d78]"
            >
              <Heart className={`h-4 w-4 ${fav ? "fill-[#ff2d78] text-[#ff2d78]" : ""}`} />
              {fav ? "Guardado" : "Guardar"}
            </button>
          </div>
          {v.descripcion && (
            <p className="mt-4 text-sm leading-relaxed text-[#b9b9c4]">{v.descripcion}</p>
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            {v.etiquetas.map((t) => (
              <TagPill key={t} etiqueta={t} />
            ))}
          </div>
        </div>
        {rel.length > 0 && (
          <aside className="shrink-0 lg:w-80">
            <h2 className="mb-3 text-sm font-medium">Relacionados</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1">
              {rel.map((x) => (
                <VideoCard key={x.id} video={x} />
              ))}
            </div>
          </aside>
        )}
      </div>
    </>
  );
}
