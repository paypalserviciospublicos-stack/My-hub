import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import Sidebar from "@/components/Sidebar";
import VideoGrid from "@/components/VideoGrid";
import { SITE_NAME, REFRESCO_MIN } from "@/lib/config";
import { refrescar } from "@/lib/videos";
import { Link } from "react-router-dom";
import TagPill from "@/components/TagPill";

const CATEGORIAS_ESTILO_INICIO = ["anal", "blowjob", "creampie", "oral", "amateur", "lesbian", "milf", "threesome", "japanese", "chinese", "russian", "pov"];

export default function Home() {
  const [nuevos, setNuevos] = useState(0);
  const [version, setVersion] = useState(0);

  // Cada pocos minutos (y al volver a la pestaña) busca vídeos nuevos.
  useEffect(() => {
    const buscar = async () => {
      const n = await refrescar();
      if (n > 0) setNuevos((x) => x + n);
    };
    const t = setInterval(buscar, REFRESCO_MIN * 60 * 1000);
    const alVolver = () => { if (document.visibilityState === "visible") buscar(); };
    document.addEventListener("visibilitychange", alVolver);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", alVolver);
    };
  }, []);

  return (
    <>
      <Helmet>
        <title>{SITE_NAME} - videos gratis</title>
        <meta name="description" content="Explora el catálogo de vídeos y sus categorías." />
      </Helmet>
      <section className="mt-6 rounded-2xl border border-[#262633] bg-[#111118] p-4 sm:p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">Categorías</h2>
            <p className="mt-1 text-xs text-[#8b8b96]">Explora el catálogo por etiquetas.</p>
          </div>
          <Link to="/categorias" className="shrink-0 text-sm font-medium text-[#ff2d78] hover:text-white">Ver todas →</Link>
        </div>
        <div className="flex flex-wrap gap-2">
          {CATEGORIAS_ESTILO_INICIO.map((c) => <TagPill key={c} etiqueta={c} />)}
        </div>
      </section>
      {nuevos > 0 && (
        <button
          onClick={() => { setNuevos(0); setVersion((v) => v + 1); window.scrollTo({ top: 0, behavior: "smooth" }); }}
          className="mt-6 w-full rounded-xl border border-[#ff2d78] bg-[#1a0f15] px-4 py-2.5 text-sm font-medium text-[#ff2d78] hover:bg-[#ff2d78] hover:text-white"
        >
          Hay {nuevos} {nuevos === 1 ? "vídeo nuevo" : "vídeos nuevos"} · Actualizar
        </button>
      )}
      <div className="mt-6 flex gap-8">
        <div className="min-w-0 flex-1">
          <VideoGrid key={version} filtro={{}} />
        </div>
        <Sidebar />
      </div>
    </>
  );
}
