import { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Tags, Search } from "lucide-react";
import { listar } from "@/lib/videos";
import type { Video } from "@/types";

// Categorías editoriales de estilo; las productoras y las fuentes no se muestran aquí.
const CATEGORIAS_ESTILO = [
  "anal", "blowjob", "creampie", "oral", "amateur", "lesbian", "milf", "mature",
  "interracial", "threesome", "gangbang", "deepthroat", "facial", "handjob",
  "public", "romantic", "hardcore", "softcore", "solo", "couple", "massage",
  "roleplay", "cosplay", "japanese", "chinese", "korean", "russian", "asian",
  "latina", "european", "big tits", "big ass", "ebony", "blonde", "brunette",
  "transgender", "femdom", "bdsm", "pov", "hd", "4k"
];
const normalizar = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLocaleLowerCase();
const coincide = (v: Video, categoria: string) => {
  const c = normalizar(categoria);
  const texto = normalizar([v.titulo, v.descripcion, ...(v.etiquetas ?? [])].join(" "));
  return new RegExp(`(^|[^a-z0-9])${c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`, "i").test(texto);
};

export default function Categorias() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [q, setQ] = useState("");
  const [cargando, setCargando] = useState(true);
  useEffect(() => {
    let activa = true;
    listar({ pagina: 1, porPagina: 1000 }).then((r) => {
      if (activa) { setVideos(r.items); setCargando(false); }
    }).catch(() => setCargando(false));
    return () => { activa = false; };
  }, []);
  const categorias = useMemo(() => CATEGORIAS_ESTILO
    .filter((nombre) => normalizar(nombre).includes(normalizar(q)))
    .map((nombre) => [nombre, videos.filter((v) => coincide(v, nombre)).length] as [string, number])
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])), [videos, q]);
  return <>
    <Helmet><title>Categorías por estilo | MiTube</title><meta name="description" content="Explora videos por estilo y etiquetas." /></Helmet>
    <section>
      <div className="mb-5 flex items-center gap-3"><div className="rounded-xl bg-[#ff2d78]/15 p-3 text-[#ff2d78]"><Tags className="h-6 w-6" /></div><div><h1 className="text-2xl font-bold">Categorías por estilo</h1><p className="mt-1 text-sm text-[#9a9aa8]">Solo estilos y etiquetas de video; no se muestran productoras.</p></div></div>
      <label className="mb-5 flex max-w-xl items-center gap-2 rounded-xl border border-[#262633] bg-[#14141c] px-4 py-3"><Search className="h-4 w-4 shrink-0 text-[#8b8b96]" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar estilo…" className="w-full bg-transparent text-sm outline-none placeholder:text-[#6b6b76]" /></label>
      {cargando ? <p className="text-sm text-[#9a9aa8]">Cargando catálogo…</p> : categorias.length ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">{categorias.map(([nombre, total]) => <Link key={nombre} to={`/etiqueta/${encodeURIComponent(nombre)}`} className="group rounded-xl border border-[#262633] bg-[#14141c] p-4 transition hover:border-[#ff2d78] hover:bg-[#1a1a24]"><div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-[#ff2d78]/10 text-[#ff2d78] group-hover:bg-[#ff2d78]/20"><Tags className="h-5 w-5" /></div><div className="break-words text-sm font-semibold text-white">{nombre}</div><div className="mt-1 text-xs text-[#8b8b96]">{total} {total === 1 ? "video" : "videos"}</div></Link>)}</div> : <p className="rounded-xl border border-[#262633] p-6 text-sm text-[#9a9aa8]">No hay estilos que coincidan.</p>}
    </section>
  </>;
}
