import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import VideoGrid from "@/components/VideoGrid";
import { fuentePorSlug } from "@/data/fuentes";

export default function Fuente() {
  const { slug = "" } = useParams();
  const f = fuentePorSlug(slug);

  return (
    <>
      <Helmet>
        <title>{f?.nombre ?? slug}</title>
      </Helmet>
      <h1 className="mb-4 mt-6 text-xl font-semibold">{f?.nombre ?? slug}</h1>
      <VideoGrid filtro={{ fuente: slug }} vacio="No hay videos de esta fuente" />
    </>
  );
}
