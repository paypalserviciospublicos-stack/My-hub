import { useSearchParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import VideoGrid from "@/components/VideoGrid";

export default function Buscar() {
  const [p] = useSearchParams();
  const q = p.get("q") ?? "";

  return (
    <>
      <Helmet>
        <title>{q ? `Resultados: ${q}` : "Buscar"}</title>
      </Helmet>
      <h1 className="mb-4 text-xl font-semibold">{q ? `Resultados para "${q}"` : "Buscar"}</h1>
      {q && <VideoGrid filtro={{ q }} vacio={`Sin resultados para "${q}"`} />}
    </>
  );
}
