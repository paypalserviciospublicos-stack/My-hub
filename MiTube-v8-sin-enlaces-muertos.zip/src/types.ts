export type Video = {
  id: string;
  fuente: string;
  origen: string;
  embed_url: string;
  video_url?: string; // archivo MP4 directo (p. ej. RedGifs); si existe se reproduce con <video>
  titulo: string;
  descripcion: string;
  miniatura: string;
  miniaturas?: string[]; // alternativas por si la principal falla o es un fotograma negro
  duracion: number | null;
  etiquetas: string[];
  vistas: number;
  fecha: string;
  publicado?: boolean;
};

export type Fuente = { slug: string; nombre: string; color: string };
