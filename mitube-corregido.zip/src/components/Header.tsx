import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Search, Heart, Clock, Flame } from "lucide-react";
import { SITE_NAME } from "@/lib/config";

export default function Header() {
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const nav = useNavigate();

  return (
    <header className="sticky top-0 z-40 border-b border-[#1c1c26] bg-[#0b0b0f]/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
        <Link to="/" className="flex items-center gap-1.5 text-lg font-semibold text-white">
          <Flame className="h-5 w-5 text-[#ff2d78]" />
          {SITE_NAME}
        </Link>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            nav(`/buscar?q=${encodeURIComponent(q)}`);
          }}
          className="mx-auto flex w-full max-w-xl items-center gap-2 rounded-full bg-[#14141c] px-4 py-2"
        >
          <Search className="h-4 w-4 text-[#8b8b96]" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar videos y etiquetas"
            className="w-full bg-transparent text-sm text-white outline-none placeholder:text-[#6b6b76]"
          />
        </form>
        <nav className="flex items-center gap-1">
          <Link to="/favoritos" aria-label="Favoritos" className="rounded-md p-2 text-[#b9b9c4] hover:text-white">
            <Heart className="h-5 w-5" />
          </Link>
          <Link to="/historial" aria-label="Historial" className="rounded-md p-2 text-[#b9b9c4] hover:text-white">
            <Clock className="h-5 w-5" />
          </Link>
        </nav>
      </div>
    </header>
  );
}
