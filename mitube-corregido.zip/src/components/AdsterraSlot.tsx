/**
 * Espacio publicitario de Adsterra.
 * Pegá aquí el código exacto del bloque (Social Bar, Native Banner o Display Banner)
 * que Adsterra te entrega en tu panel. No se inventan IDs ni scripts de zona.
 */
export default function AdsterraSlot({ label = "Publicidad" }: { label?: string }) {
  return (
    <aside
      aria-label={label}
      className="my-5 flex min-h-20 w-full items-center justify-center rounded-lg border border-dashed border-[#30303b] bg-[#101017] px-4 py-5 text-center text-xs text-[#777784]"
      data-adsterra-slot="pending-configuration"
    >
      Espacio publicitario · Configurá aquí tu código de Adsterra
    </aside>
  );
}
