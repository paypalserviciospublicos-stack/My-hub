import { Outlet } from "react-router-dom";
import Header from "./Header";
import AdsterraSlot from "./AdsterraSlot";

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#0b0b0f]">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-6">
        <AdsterraSlot label="Publicidad superior" />
        <Outlet />
        <AdsterraSlot label="Publicidad inferior" />
      </main>
      <footer className="mt-16 border-t border-[#1c1c26] py-8 text-center text-xs text-[#6b6b76]">
        Los videos se muestran mediante los reproductores originales de cada sitio.
      </footer>
    </div>
  );
}
