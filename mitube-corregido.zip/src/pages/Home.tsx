import { Helmet } from "react-helmet-async";
import FiltroFuentes from "@/components/FiltroFuentes";
import Sidebar from "@/components/Sidebar";
import VideoGrid from "@/components/VideoGrid";
import { SITE_NAME } from "@/lib/config";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>{SITE_NAME} - videos gratis</title>
        <meta name="description" content="Videos completos de los mejores estudios, gratis." />
      </Helmet>
      <FiltroFuentes />
      <div className="mt-6 flex gap-8">
        <div className="min-w-0 flex-1">
          <VideoGrid filtro={{}} />
        </div>
        <Sidebar />
      </div>
    </>
  );
}
