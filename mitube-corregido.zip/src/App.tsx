import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Video from "@/pages/Video";
import Buscar from "@/pages/Buscar";
import Fuente from "@/pages/Fuente";
import Etiqueta from "@/pages/Etiqueta";
import Favoritos from "@/pages/Favoritos";
import Historial from "@/pages/Historial";
import NoEncontrado from "@/pages/NoEncontrado";

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { path: "/", element: <Home /> },
      { path: "/video/:id", element: <Video /> },
      { path: "/buscar", element: <Buscar /> },
      { path: "/fuente/:slug", element: <Fuente /> },
      { path: "/etiqueta/:slug", element: <Etiqueta /> },
      { path: "/favoritos", element: <Favoritos /> },
      { path: "/historial", element: <Historial /> },
      { path: "*", element: <NoEncontrado /> },
    ],
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
