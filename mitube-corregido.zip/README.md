# MiTube

Web tipo tube que embebe reproductores de terceros. El catalogo se llena solo.

## Como funciona

La funcion functions/api/videos.ts se ejecuta en el borde de Cloudflare, consulta la API
publica de Pornhub con 12 busquedas (brazzers, reality kings, mofos, digital playground,
vixen, blacked, milf, latina, casting, hd, teen, anal), junta los resultados de los canales
oficiales de los estudios y devuelve un catalogo de cientos de videos COMPLETOS.

El frontend lo cachea 6 horas en el navegador. Si la funcion falla, usa el catalogo local
src/data/videos.json para que la web nunca aparezca vacia.

## Búsqueda y anuncios

- La búsqueda del visitante se envía a `/api/videos?q=...` y consulta el catálogo público de la fuente configurada.
- El caché de Cloudflare se separa por término de búsqueda para evitar devolver resultados de otra búsqueda.
- Se agregaron espacios visuales para anuncios en `src/components/AdsterraSlot.tsx`. Para activarlos, reemplazá el contenido del componente por el código exacto del bloque que Adsterra genera en tu panel. No pegues claves privadas en el frontend.
- El buscador muestra resultados que la fuente consultada devuelve públicamente; no desbloquea contenido tras un muro de pago.

## Nada que configurar

- Sin base de datos.
- Sin panel de administracion.
- Sin variables de entorno.

## Desarrollo

    npm install
    npm run dev

Nota: en local no hay Functions, asi que se usa el catalogo de ejemplo. Es normal.

## Despliegue en Cloudflare Pages

- Framework preset: Vite
- Build command: npm run build
- Build output directory: dist
- Variable de entorno: NODE_VERSION = 20

La carpeta functions/ se despliega sola.

## Para cambiar las busquedas

Edita el array BUSQUEDAS en functions/api/videos.ts.
