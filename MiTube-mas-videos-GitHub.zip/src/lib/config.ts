export const SITE_NAME = "MiTube";
export const CACHE_HORAS = 1;
