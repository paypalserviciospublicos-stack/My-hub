import type { Fuente } from "@/types";

// Solo proveedores consultados por el backend de forma predeterminada.
// XNXX, YouPorn, RedTube, XHamster y Txxx aparecen cuando se configura una
// instancia propia compatible con Lustpress en LUSTPRESS_API_BASE.
export const FUENTES: Fuente[] = [
  { slug: "pornhub", nombre: "Pornhub", color: "#f96d00" },
  { slug: "eporner", nombre: "Eporner", color: "#f96d00" },
  { slug: "xvideos", nombre: "XVideos", color: "#d4132a" },
  { slug: "redtube", nombre: "RedTube", color: "#e30613" },
  { slug: "avgle", nombre: "Avgle · JAV", color: "#5b70c8" },
  { slug: "xnxx", nombre: "XNXX · agregador opcional", color: "#1a9c4b" },
  { slug: "youporn", nombre: "YouPorn · agregador opcional", color: "#1a8fd1" },
  { slug: "redtube", nombre: "RedTube · agregador opcional", color: "#e30613" },
  { slug: "xhamster", nombre: "XHamster · agregador opcional", color: "#ff9000" },
  { slug: "txxx", nombre: "Txxx · agregador opcional", color: "#8e44ad" },
];

export const fuentePorSlug = (slug: string) => FUENTES.find((f) => f.slug === slug);
