const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const BUSQUEDAS = [
  "amateur", "anal", "oral", "blowjob", "creampie", "deepthroat",
  "lesbian", "milf", "mature", "interracial", "threesome", "gangbang",
  "handjob", "facial", "public", "romantic", "solo", "couple", "massage",
  "roleplay", "cosplay", "japanese", "japan", "chinese", "china", "korean",
  "russian", "russia", "asian", "latina", "european", "big tits", "big ass",
  "ebony", "blonde", "brunette", "transgender", "femdom", "bdsm", "pov", "4k",
  "amateur anal", "japanese amateur", "chinese amateur", "russian amateur",
  "asian amateur", "latina amateur", "milf amateur", "lesbian amateur",
];

const cabeceras = { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9" };
const ESTILOS = new Set(["anal", "blowjob", "creampie", "oral", "amateur", "lesbian", "milf", "mature", "interracial", "threesome", "gangbang", "deepthroat", "facial", "handjob", "public", "romantic", "hardcore", "softcore", "solo", "couple", "massage", "roleplay", "cosplay", "japanese", "chinese", "korean", "russian", "asian", "latina", "european", "big tits", "big ass", "ebony", "blonde", "brunette", "transgender", "femdom", "bdsm", "pov", "hd", "4k"]);
function limpiarEtiquetas(tags: any[]): string[] {
  return [...new Set(tags.map((x) => String(x?.name ?? x ?? "").trim().toLowerCase()).filter((x) => ESTILOS.has(x)))].slice(0, 20);
}

function aSegundos(t: unknown): number | null {
  if (t === null || t === undefined || t === "") return null;
  const s = String(t);
  if (s.includes(":")) {
    const p = s.split(":").map((x) => parseInt(x, 10) || 0);
    return p.reduce((a, b) => a * 60 + b, 0);
  }
  const n = parseInt(s.replace(/\D/g, ""), 10);
  return isNaN(n) ? null : n;
}

function extraerMiniatura(value: any): string {
  const candidates = Array.isArray(value) ? value : [value];
  for (const item of candidates) {
    const raw = typeof item === "string" ? item : item?.src ?? item?.url ?? item?.thumb ?? item?.image;
    if (typeof raw === "string" && /^https?:\/\//i.test(raw) && !/picsum\.photos|placeholder|no[-_ ]?image/i.test(raw)) return raw;
  }
  return "";
}

function normalizar(v: any) {
  const id = v?.video_id;
  if (!id) return null;
  const etiquetas = limpiarEtiquetas([
    ...((v.tags ?? []) as any[]).map((t) => t?.tag_name),
    ...((v.categories ?? []) as any[]).map((c) => c?.category),
  ]);

  return {
    id: "ph-" + id,
    fuente: "pornhub",
    origen: v.url ?? "https://www.pornhub.com/view_video.php?viewkey=" + id,
    embed_url: "https://www.pornhub.com/embed/" + id,
    titulo: v.title ?? "Sin titulo",
    descripcion: ((v.tags ?? []) as any[]).map((t) => t?.tag_name).filter(Boolean).join(", "),
    miniatura: extraerMiniatura(v.thumb) || extraerMiniatura(v.default_thumb),
    duracion: aSegundos(v.duration),
    etiquetas: [...new Set(etiquetas)].slice(0, 8),
    vistas: parseInt(String(v.views ?? "0").replace(/\D/g, ""), 10) || 0,
    fecha: v.publish_date ?? new Date().toISOString(),
    publicado: true,
  };
}


function normalizarEporner(v: any) {
  if (!v?.id) return null;
  const etiquetas = limpiarEtiquetas(String(v.keywords ?? "").split(/[;,]/));
  const miniatura = extraerMiniatura(v.default_thumb) || extraerMiniatura(v.thumb);
  return {
    id: "eporner-" + v.id,
    fuente: "eporner",
    origen: v.url ?? `https://www.eporner.com/hd-porn/${v.id}/`,
    embed_url: v.embed ?? `https://www.eporner.com/embed/${v.id}/`,
    titulo: v.title ?? "Sin título",
    descripcion: String(v.keywords ?? ""),
    miniatura,
    duracion: Number.isFinite(Number(v.length_sec)) ? Number(v.length_sec) : aSegundos(v.length_min),
    etiquetas: [...new Set(etiquetas)].slice(0, 20),
    vistas: Number(v.views ?? 0) || 0,
    fecha: v.added && !String(v.added).startsWith("1970") ? new Date(v.added.replace(" ", "T") + "Z").toISOString() : new Date().toISOString(),
    publicado: true,
  };
}

async function porTerminoEporner(term: string, page = 1) {
  try {
    const params = new URLSearchParams({ query: term || "all", per_page: "100", page: String(page), thumbsize: "big", order: "latest", format: "json" });
    const r = await fetch(`https://www.eporner.com/api/v2/video/search/?${params.toString()}`, { headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(7000) });
    if (!r.ok) return [];
    const d: any = await r.json();
    return (Array.isArray(d?.videos) ? d.videos : []).map(normalizarEporner).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}


function normalizarRedTube(v: any) {
  const x = v?.video ?? v;
  const id = x?.video_id ?? x?.id;
  const titulo = x?.video_title ?? x?.title;
  const url = x?.video_url ?? x?.url;
  if (!id || !titulo || !url) return null;
  const thumbs = x?.default_thumb ?? x?.thumb ?? x?.thumbs;
  const miniatura = extraerMiniatura(thumbs);
  const etiquetas = limpiarEtiquetas(String(x?.tags ?? x?.categories ?? titulo).split(/[;,\s]+/));
  return { id: `redtube-${id}`, fuente: "redtube", origen: url,
    embed_url: x?.embed_url ?? `https://embed.redtube.com/?id=${encodeURIComponent(id)}&bgcolor=000000`,
    titulo: decodificarHtml(String(titulo)), descripcion: String(x?.tags ?? ""), miniatura,
    duracion: aSegundos(x?.duration), etiquetas, vistas: Number(x?.views ?? 0) || 0,
    fecha: x?.publish_date ?? new Date().toISOString(), publicado: true };
}

async function porTerminoRedTube(term: string, page = 1) {
  try {
    const params = new URLSearchParams({ data: "redtube.Videos.searchVideos", output: "json", search: term || "milf", page: String(page) });
    const r = await fetch(`https://api.redtube.com/?${params}`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(7000) });
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr = d?.videos?.video ?? d?.videos ?? d?.video ?? [];
    return (Array.isArray(arr) ? arr : [arr]).map(normalizarRedTube).filter(Boolean) as any[];
  } catch { return []; }
}

// Avgle es un endpoint comunitario/no garantizado; solo se usa si devuelve JSON válido.
async function porTerminoAvgle(term: string, page = 1) {
  try {
    const offset = Math.max(0, page - 1);
    const r = await fetch(`https://api.avgle.com/v1/search/${encodeURIComponent(term || "jav")}/${offset}?limit=20`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(7000) });
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr = d?.response?.videos ?? d?.videos ?? [];
    return (Array.isArray(arr) ? arr : []).map((v: any) => {
      const id = v?.vid ?? v?.id; const titulo = v?.title;
      if (!id || !titulo) return null;
      const embed = v?.embedded_url ?? v?.embed_url ?? v?.url;
      const origen = v?.url ?? `https://avgle.com/video/${id}`;
      return { id: `avgle-${id}`, fuente: "avgle", origen, embed_url: embed || origen,
        titulo: decodificarHtml(String(titulo)), descripcion: String(v?.keyword ?? ""),
        miniatura: extraerMiniatura(v?.preview_url) || extraerMiniatura(v?.preview_video_url),
        duracion: aSegundos(v?.duration), etiquetas: limpiarEtiquetas(String(v?.keyword ?? titulo).split(/[;,\s]+/)),
        vistas: Number(v?.viewnumber ?? 0) || 0, fecha: new Date().toISOString(), publicado: true };
    }).filter(Boolean) as any[];
  } catch { return []; }
}

function decodificarHtml(s: string) {
  return s
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)));
}

// XVideos no publica una API oficial estable. Este adaptador lee únicamente
// tarjetas públicas de la página de búsqueda y falla silenciosamente si cambia
// el HTML o el proveedor bloquea peticiones automatizadas.
function normalizarXVideos(htmlCard: string) {
  const id = htmlCard.match(/id=["']video_(\d+)["']/i)?.[1]
    ?? htmlCard.match(/data-video-id=["'](\d+)["']/i)?.[1];
  const link = htmlCard.match(/<a[^>]+href=["']([^"']*\/video[^"']*)["'][^>]*>/i);
  const href = link?.[1];
  const titulo = (htmlCard.match(/<a[^>]+href=["'][^"']*\/video[^"']*["'][^>]+title=["']([^"']+)["']/i)?.[1]
    ?? htmlCard.match(/title=["']([^"']+)["']/i)?.[1] ?? "").trim();
  const miniatura = htmlCard.match(/(?:data-src|data-original|data-thumb)=["'](https?:[^"']+|\/[^"']+)["']/i)?.[1] ?? "";
  const duracion = htmlCard.match(/class=["'][^"']*(?:duration|thumb-under)[^"']*["'][^>]*>\s*([^<]{1,20})/i)?.[1]
    ?? htmlCard.match(/([0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)/)?.[1];
  if (!id || !href || !titulo) return null;
  const origen = href.startsWith("http") ? href : `https://www.xvideos.com${href}`;
  const tags = limpiarEtiquetas(titulo.toLowerCase().split(/[^\p{L}\p{N}]+/u));
  return {
    id: `xvideos-${id}`, fuente: "xvideos", origen, embed_url: `https://www.xvideos.com/embedframe/${id}`,
    titulo: decodificarHtml(titulo), descripcion: "Resultados públicos de XVideos",
    miniatura: miniatura.startsWith("/") ? `https://www.xvideos.com${miniatura}` : (/^https?:\/\//i.test(miniatura) && !/picsum\.photos|placeholder|no[-_ ]?image/i.test(miniatura) ? miniatura : ""),
    duracion: aSegundos(duracion), etiquetas: [...new Set(tags)].slice(0, 20),
    vistas: 0, fecha: new Date().toISOString(), publicado: true,
  };
}

async function porTerminoXVideos(term: string, page = 1) {
  try {
    const u = new URL("https://www.xvideos.com/");
    u.searchParams.set("k", term || "all");
    u.searchParams.set("p", String(Math.max(0, page - 1)));
    const r = await fetch(u.toString(), {
      headers: { "User-Agent": UA, "Accept": "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" },
      signal: AbortSignal.timeout(7000),
    });
    if (!r.ok) return [];
    const html = await r.text();
    const cards = html.match(/<div\b[^>]*(?:thumb-block|thumb-container)[^>]*>[\s\S]*?<\/div>\s*<\/div>/gi) ?? [];
    return cards.map(normalizarXVideos).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}

async function porTermino(term: string) {
  try {
    const r = await fetch(
      "https://www.pornhub.com/webmasters/search?search=" +
        encodeURIComponent(term) +
        "&thumb_size=medium",
      { headers: cabeceras, signal: AbortSignal.timeout(7000) }
    );
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr: any[] = d?.videos ?? d?.video ?? [];
    return arr.map(normalizar).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}

// Lustpress es un agregador open-source para varias webs, pero su playground público fue
// discontinuado. Solo se consulta si el administrador configura una instancia propia.
function normalizarLustpress(v: any, fuente: string) {
  const id = v?.id ?? v?.video_id;
  const titulo = v?.title ?? v?.titulo;
  const origen = v?.link ?? v?.url ?? v?.origin;
  if (!id || !titulo || !origen) return null;
  const tags = Array.isArray(v.tags) ? v.tags : Array.isArray(v.keywords) ? v.keywords : String(v.tags ?? v.keywords ?? "").split(/[;,]/);
  return {
    id: `lust-${fuente}-${id}`, fuente,
    origen, embed_url: v.embed ?? v.embed_url ?? origen,
    titulo, descripcion: String(v.description ?? v.descripcion ?? tags.join(", ")),
    miniatura: extraerMiniatura(v.thumbnail) || extraerMiniatura(v.thumb) || extraerMiniatura(v.image) || extraerMiniatura(v.preview),
    duracion: aSegundos(v.duration ?? v.length),
    etiquetas: limpiarEtiquetas(tags),
    vistas: Number(v.views ?? 0) || 0,
    fecha: v.uploaded ?? v.date ?? new Date().toISOString(), publicado: true,
  };
}

async function porTerminoLustpress(base: string, fuente: string, term: string, page = 1) {
  try {
    const u = new URL(`/${fuente}/search`, base);
    u.searchParams.set("key", term || "all");
    u.searchParams.set("page", String(Math.max(1, Math.min(5, page))));
    const r = await fetch(u.toString(), { headers: { "Accept": "application/json", ...cabeceras }, signal: AbortSignal.timeout(7000) });
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr = d?.data?.data ?? d?.data ?? d?.videos ?? [];
    return (Array.isArray(arr) ? arr : []).map((v: any) => normalizarLustpress(v, fuente)).filter(Boolean);
  } catch { return []; }
}

export async function onRequestGet({ request, env }: any) {
  const url = new URL(request.url);
  const termino = (url.searchParams.get("q") ?? "").trim().slice(0, 120);
  // La paginación se limita para evitar peticiones excesivas a las fuentes públicas.
  const paginaSolicitada = Math.max(1, Math.min(5, Number(url.searchParams.get("page")) || 1));
  const cachePath = "/api/videos?v=3" +
    (termino ? "&q=" + encodeURIComponent(termino.toLowerCase()) + "&page=" + paginaSolicitada : "&home=1") +
    "&xv=" + (String(env?.ENABLE_XVIDEOS ?? "true").toLowerCase() === "false" ? "0" : "1") +
    "&lp=" + (String(env?.LUSTPRESS_API_BASE ?? "").trim() ? "1" : "0");
  const cacheKey = new Request(url.origin + cachePath, { method: "GET" });

  try {
    const hit = await caches.default.match(cacheKey);
    if (hit) return hit;
  } catch {}

  // En búsqueda, cada petición consulta una sola página por fuente para mantener
  // tiempos de respuesta predecibles. La UI puede pedir page=2, page=3, etc.
  const terminos = termino ? [termino] : BUSQUEDAS;
  const lotes: any[][] = [];
  if (termino) {
    const [ph, ep, xv, rt, av] = await Promise.all([
      porTermino(termino), porTerminoEporner(termino, paginaSolicitada),
      String(env?.ENABLE_XVIDEOS ?? "true").toLowerCase() === "false" ? Promise.resolve([]) : porTerminoXVideos(termino, paginaSolicitada),
      porTerminoRedTube(termino, paginaSolicitada), porTerminoAvgle(termino, paginaSolicitada),
    ]);
    lotes.push(ph, ep, xv, rt, av);
  } else {
    // Portada: consultas generales en lotes pequeños y una selección de páginas
    // iniciales de Eporner. XVideos se reserva para búsquedas para no demorar el inicio.
    // Consultas variadas para que la portada no dependa de una única etiqueta.
    // Se limita el número de consultas por petición y se mezclan fuentes al final.
    const terminosInicio = ["amateur", "anal", "oral", "japanese", "asian", "latina", "milf", "lesbian", "russian", "chinese", "russian amateur", "chinese amateur"];
    const terminosEporner = ["all", "amateur", "anal", "japanese", "asian", "latina", "milf", "lesbian", "russian", "chinese"];
    const [lotesPornhub, lotesEporner, lotesXVideos, lotesRedTube, lotesAvgle] = await Promise.all([
      Promise.all(terminosInicio.map(porTermino)),
      Promise.all(terminosEporner.map((t) => porTerminoEporner(t, 1))),
      String(env?.ENABLE_XVIDEOS ?? "true").toLowerCase() === "false"
        ? Promise.resolve([])
        : Promise.all(["amateur", "japanese", "chinese", "russian", "asian"].map((t) => porTerminoXVideos(t, 1))),
      Promise.all(["amateur", "japanese", "milf"].map((t) => porTerminoRedTube(t, 1))),
      Promise.all(["jav", "japanese", "amateur"].map((t) => porTerminoAvgle(t, 1))),
    ]);
    lotes.push(...lotesPornhub, ...lotesEporner, ...lotesXVideos, ...lotesRedTube, ...lotesAvgle);
  }

  // Si se configura LUSTPRESS_API_BASE con una instancia propia, suma resultados de
  // Xvideos, XNXX, YouPorn, RedTube, XHamster y Txxx sin depender de un demo discontinuado.
  const agregadorLotes: any[][] = [];
  const lustBase = String(env?.LUSTPRESS_API_BASE ?? "").trim();
  if (lustBase) {
    const sitios = ["xvideos", "xnxx", "youporn", "redtube", "xhamster", "txxx"];
    const q = termino || "anal";
    for (let i = 0; i < sitios.length; i += 3) {
      agregadorLotes.push(...(await Promise.all(sitios.slice(i, i + 3).map((site) => porTerminoLustpress(lustBase, site, q, paginaSolicitada)))));
    }
  }

  // Agrupar por fuente y alternar resultados: evita que una API con más
  // resultados monopolice las primeras filas de la portada.
  const porFuente = new Map<string, any[]>();
  for (const lote of [...lotes, ...agregadorLotes]) {
    for (const v of lote) {
      if (!v) continue;
      const grupo = porFuente.get(v.fuente) ?? [];
      if (!grupo.some((x) => x.id === v.id)) grupo.push(v);
      porFuente.set(v.fuente, grupo);
    }
  }
  const videos: any[] = [];
  const fuentesOrdenadas = [...porFuente.keys()];
  let indice = 0;
  while (fuentesOrdenadas.some((f) => (porFuente.get(f)?.length ?? 0) > indice)) {
    for (const fuente of fuentesOrdenadas) {
      const v = porFuente.get(fuente)?.[indice];
      if (v) videos.push(v);
    }
    indice++;
  }
  videos.sort((a, b) => +new Date(b.fecha) - +new Date(a.fecha));
  // La ordenación por fecha puede volver a agrupar fuentes; intercalar de nuevo
  // conserva diversidad y prioriza recencia dentro de cada fuente.
  const gruposRecientes = new Map<string, any[]>();
  for (const v of videos) {
    const g = gruposRecientes.get(v.fuente) ?? [];
    g.push(v);
    gruposRecientes.set(v.fuente, g);
  }
  const mezcla: any[] = [];
  const fuentesRecientes = [...gruposRecientes.keys()];
  for (let i = 0; fuentesRecientes.some((f) => (gruposRecientes.get(f)?.length ?? 0) > i); i++) {
    for (const f of fuentesRecientes) {
      const v = gruposRecientes.get(f)?.[i];
      if (v) mezcla.push(v);
    }
  }

  const res = new Response(
    JSON.stringify({ videos: mezcla, total: mezcla.length, fuentes: fuentesRecientes, generado: new Date().toISOString() }),
    {
      status: 200,
      headers: {
        "content-type": "application/json;charset=utf-8",
        "cache-control": "public, max-age=21600",
        "access-control-allow-origin": "*",
      },
    }
  );

  if (videos.length) {
    try {
      await caches.default.put(cacheKey, res.clone());
    } catch {}
  }

  return res;
}
