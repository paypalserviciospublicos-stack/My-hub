# MiTube

Aplicación React + Vite para explorar metadatos públicos de videos y abrirlos en los reproductores o páginas originales. No aloja ni desbloquea videos de terceros.

## Funciones

- Catálogo con búsqueda, filtros por fuente y etiquetas.
- Sección **Categorías** con buscador, recuento de resultados y enlaces a cada etiqueta.
- Carga progresiva de tarjetas desde el catálogo disponible.
- Favoritos e historial locales.
- Componente publicitario existente conservado en `src/components/Anuncios.tsx`; no se modificó durante la ampliación de búsqueda.

## Cómo se obtienen los resultados

`functions/api/videos.ts` consulta el endpoint de búsqueda pública configurado y combina resultados de varios términos. La disponibilidad y el número de resultados dependen de la API de origen, sus límites, el contenido accesible desde la región y los cambios que haga el proveedor. No garantiza cientos de resultados ni consulta directamente los catálogos privados de estudios.

Para integrar catálogos de estudios de pago, utiliza sus API, feeds o enlaces de afiliado autorizados. La aplicación no debe intentar saltarse suscripciones, autenticación, DRM ni otras protecciones de acceso.

## Desarrollo

```sh
npm install
npm run dev
```

## Despliegue en Cloudflare Pages

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Configura Node.js 20 o superior para la compilación.
- La carpeta `functions/` contiene la función `/api/videos`.

## Ampliar categorías

Las categorías se derivan de las etiquetas devueltas por la fuente y de las etiquetas del catálogo local. Una etiqueta solo muestra recuentos basados en elementos existentes en el catálogo.


## Fuentes externas y variables de Cloudflare

La ruta `functions/api/videos.ts` consulta Pornhub Webmasters y Eporner para resultados públicos. XVideos se consulta como fuente secundaria de mejor esfuerzo porque no ofrece una API oficial estable y su HTML puede cambiar.

En Cloudflare Pages > Settings > Variables and Secrets, puedes configurar:

- `ENABLE_XVIDEOS`: `true` para habilitar el adaptador comunitario de XVideos o `false` para desactivarlo.
- `LUSTPRESS_API_BASE`: opcional; URL base de una instancia propia compatible con la API de Lustpress. No configures esta variable si no administras una instancia compatible.

No se necesita ninguna clave API para la integración actual de Pornhub Webmasters/Eporner. No se deben poner secretos en variables `VITE_*`, porque quedan expuestos al navegador. Adult.Link no se usa como proveedor de búsqueda de vídeos en esta versión, ya que no es una API equivalente de catálogo; úsalo solo si tienes un feed/documentación específica y autorizada que confirme el endpoint adecuado.

La fuente XVideos es opcional y puede dejar de responder si el proveedor bloquea solicitudes desde Cloudflare o cambia el HTML. La búsqueda debe seguir funcionando con las demás fuentes.
