const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const BUSQUEDAS = [
  // Consultas de catálogo público; no extraen ni desbloquean contenido de pago.
  "brazzers",
  "reality kings",
  "mofos",
  "digital playground",
  "blacked",
  "blacked raw",
  "loves anal",
  "culioneros",
  "fake taxi",
  "public agent",
  "milf hunter",
  "first anal quest",
  "amateur",
  "latina",
  "casting",
  "hd",
  "anal",
  "japanese",
  "lesbian",
  "transgender",
  "reality",
  "interracial",
];

const cabeceras = { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9" };

function aSegundos(t: unknown): number | null {
  if (t === null || t === undefined || t === "") return null;
  const s = String(t);
  if (s.includes(":")) {
    const p = s.split(":").map((x) => parseInt(x, 10) || 0);
    return p.reduce((a, b) => a * 60 + b, 0);
  }
  const n = parseInt(s.replace(/\D/g, ""), 10);
  return isNaN(n) ? null : n;
}

function normalizar(v: any) {
  const id = v?.video_id;
  if (!id) return null;
  const etiquetas: string[] = [
    ...((v.tags ?? []) as any[]).map((t) => t?.tag_name),
    ...((v.categories ?? []) as any[]).map((c) => c?.category),
  ]
    .filter(Boolean)
    .map((s: string) => s.toLowerCase());

  return {
    id: "ph-" + id,
    fuente: "pornhub",
    origen: v.url ?? "https://www.pornhub.com/view_video.php?viewkey=" + id,
    embed_url: "https://www.pornhub.com/embed/" + id,
    titulo: v.title ?? "Sin titulo",
    descripcion: ((v.tags ?? []) as any[]).map((t) => t?.tag_name).filter(Boolean).join(", "),
    miniatura: v.thumb ?? v.default_thumb ?? "",
    duracion: aSegundos(v.duration),
    etiquetas: [...new Set(etiquetas)].slice(0, 8),
    vistas: parseInt(String(v.views ?? "0").replace(/\D/g, ""), 10) || 0,
    fecha: v.publish_date ?? new Date().toISOString(),
    publicado: true,
  };
}

async function porTermino(term: string) {
  try {
    const r = await fetch(
      "https://www.pornhub.com/webmasters/search?search=" +
        encodeURIComponent(term) +
        "&thumb_size=medium",
      { headers: cabeceras }
    );
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr: any[] = d?.videos ?? d?.video ?? [];
    return arr.map(normalizar).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}

export async function onRequestGet({ request }: any) {
  const url = new URL(request.url);
  const termino = (url.searchParams.get("q") ?? "").trim().slice(0, 120);
  const cachePath = termino
    ? "/api/videos?q=" + encodeURIComponent(termino.toLowerCase())
    : "/api/videos";
  const cacheKey = new Request(url.origin + cachePath, { method: "GET" });

  try {
    const hit = await caches.default.match(cacheKey);
    if (hit) return hit;
  } catch {}

  // Si el visitante busca algo, consultamos ese término; la portada usa las búsquedas generales.
  const terminos = termino ? [termino] : BUSQUEDAS;
  // Limita concurrencia para no saturar la API pública ni agotar el tiempo de Cloudflare.
  const lotes: any[][] = [];
  for (let i = 0; i < terminos.length; i += 5) {
    const grupo = await Promise.all(terminos.slice(i, i + 5).map(porTermino));
    lotes.push(...grupo);
  }

  const vistos = new Set<string>();
  const videos: any[] = [];
  for (const lote of lotes) {
    for (const v of lote) {
      if (!v || vistos.has(v.id)) continue;
      vistos.add(v.id);
      videos.push(v);
    }
  }
  videos.sort((a, b) => +new Date(b.fecha) - +new Date(a.fecha));

  const res = new Response(
    JSON.stringify({ videos, total: videos.length, generado: new Date().toISOString() }),
    {
      status: 200,
      headers: {
        "content-type": "application/json;charset=utf-8",
        "cache-control": "public, max-age=21600",
        "access-control-allow-origin": "*",
      },
    }
  );

  if (videos.length) {
    try {
      await caches.default.put(cacheKey, res.clone());
    } catch {}
  }

  return res;
}
