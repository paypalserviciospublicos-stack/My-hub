import { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Tags, Search } from "lucide-react";
import { listar } from "@/lib/videos";
import type { Video } from "@/types";

const normalizar = (s: string) => s.trim().toLocaleLowerCase();

export default function Categorias() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [q, setQ] = useState("");
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    let activa = true;
    listar({ pagina: 1, porPagina: 1000 }).then((r) => {
      if (activa) {
        setVideos(r.items);
        setCargando(false);
      }
    }).catch(() => setCargando(false));
    return () => { activa = false; };
  }, []);

  const categorias = useMemo(() => {
    const cuenta = new Map<string, number>();
    videos.forEach((v) => {
      (v.etiquetas ?? []).forEach((tag) => {
        const limpio = tag.trim();
        if (!limpio || limpio.length > 40) return;
        cuenta.set(limpio, (cuenta.get(limpio) ?? 0) + 1);
      });
    });
    return [...cuenta.entries()]
      .filter(([nombre]) => normalizar(nombre).includes(normalizar(q)))
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  }, [videos, q]);

  return (
    <>
      <Helmet>
        <title>Categorías | MiTube</title>
        <meta name="description" content="Explora el catálogo de MiTube por categorías y etiquetas disponibles." />
      </Helmet>
      <section>
        <div className="mb-5 flex items-center gap-3">
          <div className="rounded-xl bg-[#ff2d78]/15 p-3 text-[#ff2d78]"><Tags className="h-6 w-6" /></div>
          <div>
            <h1 className="text-2xl font-bold">Categorías</h1>
            <p className="mt-1 text-sm text-[#9a9aa8]">Elige una categoría para ver los videos etiquetados con ella.</p>
          </div>
        </div>
        <label className="mb-5 flex max-w-xl items-center gap-2 rounded-xl border border-[#262633] bg-[#14141c] px-4 py-3">
          <Search className="h-4 w-4 shrink-0 text-[#8b8b96]" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar una categoría…" className="w-full bg-transparent text-sm outline-none placeholder:text-[#6b6b76]" />
        </label>
        {cargando ? <p className="text-sm text-[#9a9aa8]">Cargando categorías del catálogo…</p> : categorias.length ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {categorias.map(([nombre, total]) => (
              <Link key={nombre} to={`/etiqueta/${encodeURIComponent(nombre)}`} className="group rounded-xl border border-[#262633] bg-[#14141c] p-4 transition hover:border-[#ff2d78] hover:bg-[#1a1a24]">
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-[#ff2d78]/10 text-[#ff2d78] group-hover:bg-[#ff2d78]/20"><Tags className="h-5 w-5" /></div>
                <div className="break-words text-sm font-semibold text-white">{nombre}</div>
                <div className="mt-1 text-xs text-[#8b8b96]">{total} {total === 1 ? "video" : "videos"}</div>
              </Link>
            ))}
          </div>
        ) : <p className="rounded-xl border border-[#262633] p-6 text-sm text-[#9a9aa8]">No hay categorías que coincidan. Prueba con otra búsqueda o sincroniza el catálogo.</p>}
      </section>
    </>
  );
}
