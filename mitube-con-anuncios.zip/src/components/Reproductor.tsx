import { useState } from "react";
import { Play } from "lucide-react";
import type { Video } from "@/types";

export default function Reproductor({ video, directo = false }: { video: Video; directo?: boolean }) {
  const [activo, setActivo] = useState(directo);

  if (activo) {
    return (
      <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black">
        <iframe
          src={video.embed_url}
          title={video.titulo}
          className="absolute inset-0 h-full w-full"
          allowFullScreen
          allow="autoplay; fullscreen; encrypted-media"
        />
      </div>
    );
  }

  return (
    <button
      onClick={() => setActivo(true)}
      className="group relative block aspect-video w-full overflow-hidden rounded-xl bg-black"
    >
      <img
        src={video.miniatura}
        alt={video.titulo}
        loading="lazy"
        className="h-full w-full object-cover opacity-80 transition group-hover:opacity-100"
      />
      <span className="absolute inset-0 grid place-items-center">
        <span className="grid h-16 w-16 place-items-center rounded-full bg-[#ff2d78] text-white">
          <Play className="h-7 w-7 translate-x-0.5" />
        </span>
      </span>
    </button>
  );
}
