import { useEffect, useState } from "react";
import { etiquetasPopulares } from "@/lib/videos";
import TagPill from "./TagPill";

export default function Sidebar() {
  const [tags, setTags] = useState<string[]>([]);

  useEffect(() => {
    etiquetasPopulares(24).then(setTags);
  }, []);

  return (
    <aside className="hidden w-56 shrink-0 lg:block">
      <h2 className="mb-3 text-sm font-medium">Etiquetas</h2>
      <div className="flex flex-wrap gap-2">
        {tags.map((t) => (
          <TagPill key={t} etiqueta={t} />
        ))}
      </div>
    </aside>
  );
}
