export type Video = {
  id: string;
  fuente: string;
  origen: string;
  embed_url: string;
  titulo: string;
  descripcion: string;
  miniatura: string;
  duracion: number | null;
  etiquetas: string[];
  vistas: number;
  fecha: string;
  publicado?: boolean;
};

export type Fuente = { slug: string; nombre: string; color: string };
