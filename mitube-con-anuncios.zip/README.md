# MiTube

Aplicación React + Vite para explorar metadatos públicos de videos y abrirlos en los reproductores o páginas originales. No aloja ni desbloquea videos de terceros.

## Funciones

- Catálogo con búsqueda, filtros por fuente y etiquetas.
- Sección **Categorías** con buscador, recuento de resultados y enlaces a cada etiqueta.
- Carga progresiva de tarjetas desde el catálogo disponible.
- Favoritos e historial locales.
- Sin espacios publicitarios reservados; la integración publicitaria se añadirá después usando el código oficial de la red elegida.

## Cómo se obtienen los resultados

`functions/api/videos.ts` consulta el endpoint de búsqueda pública configurado y combina resultados de varios términos. La disponibilidad y el número de resultados dependen de la API de origen, sus límites, el contenido accesible desde la región y los cambios que haga el proveedor. No garantiza cientos de resultados ni consulta directamente los catálogos privados de estudios.

Para integrar catálogos de estudios de pago, utiliza sus API, feeds o enlaces de afiliado autorizados. La aplicación no debe intentar saltarse suscripciones, autenticación, DRM ni otras protecciones de acceso.

## Desarrollo

```sh
npm install
npm run dev
```

## Despliegue en Cloudflare Pages

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Configura Node.js 20 o superior para la compilación.
- La carpeta `functions/` contiene la función `/api/videos`.

## Ampliar categorías

Las categorías se derivan de las etiquetas devueltas por la fuente y de las etiquetas del catálogo local. Una etiqueta solo muestra recuentos basados en elementos existentes en el catálogo.
