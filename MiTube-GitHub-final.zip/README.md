# MiTube

Catálogo web en React + Vite para explorar metadatos y enlaces públicos de vídeos de terceros. MiTube no aloja, descarga, desbloquea ni evita restricciones de acceso de otros sitios.

## Funciones

- Búsqueda remota y catálogo local de respaldo.
- Resultados combinados y alternados por proveedor para evitar que una sola fuente monopolice las primeras tarjetas.
- Categorías por estilo (por ejemplo: anal, oral, amateur, milf, lesbian, Japanese, Chinese, Russian, POV y 4K); no se muestran productoras como categorías.
- Filtro por proveedor, etiquetas, favoritos e historial local.
- Adaptadores predeterminados para Pornhub Webmasters, Eporner API v2 y un adaptador de mejor esfuerzo para resultados públicos de XVideos.
- Integración opcional con una instancia propia compatible con Lustpress para agregar XNXX, YouPorn, RedTube, XHamster y Txxx.
- Caché del navegador y caché de respuesta en Cloudflare cuando está disponible.

## Requisitos

- Node.js 20 o superior recomendado.
- npm.
- Para la API en producción, desplegar como **Cloudflare Pages** (el directorio `functions/` usa Cloudflare Pages Functions). El modo `vite dev` por sí solo sirve la interfaz, pero no ejecuta necesariamente la función de Cloudflare.

## Desarrollo local

```bash
npm install
npm run dev
```

Para probar la función `/api/videos` localmente, instala Wrangler y ejecuta el entorno de Pages:

```bash
npx wrangler pages dev dist
```

Primero genera `dist` con `npm run build`. Consulta la documentación de Cloudflare Pages para los detalles del flujo local y las variables de entorno.

## Publicar en GitHub

1. Descomprime el ZIP.
2. Crea un repositorio nuevo en GitHub y sube el contenido de esta carpeta (no subas `node_modules`).
3. En Cloudflare Pages, conecta el repositorio.
4. Configura el comando de compilación `npm run build` y el directorio de salida `dist`.
5. Despliega y prueba `/api/videos` en el dominio publicado.

## Variables opcionales de Cloudflare Pages

Configúralas en **Settings → Variables and Secrets**. No uses variables `VITE_*` para secretos: se exponen al navegador.

| Variable | Valor | Uso |
|---|---|---|
| `ENABLE_XVIDEOS` | `true` o `false` | Activa/desactiva el adaptador de búsqueda pública de XVideos. Predeterminado: activado. |
| `LUSTPRESS_API_BASE` | URL base de una instancia propia y compatible | Activa consultas a XNXX, YouPorn, RedTube, XHamster y Txxx mediante endpoints compatibles de Lustpress. Si no tienes una instancia funcionando, deja la variable vacía. |

### Fuentes y límites

- **Eporner**: API pública documentada en <https://github.com/eporner/API>.
- **Pornhub**: Webmasters Search API. La disponibilidad depende de la respuesta de la plataforma.
- **XVideos**: el adaptador interpreta tarjetas de búsqueda públicas y puede dejar de funcionar si cambia el HTML o el proveedor limita peticiones; se puede desactivar con `ENABLE_XVIDEOS=false`.
- **Lustpress**: proyecto comunitario que puede agregar otras plataformas. MiTube no depende de una instancia pública compartida. Despliega y administra tu propia instancia compatible y configura `LUSTPRESS_API_BASE` para habilitarla. Documentación: <https://github.com/sinkaroid/lustpress>.

No todas las plataformas ofrecen API pública oficial. Por eso, la presencia de una categoría regional como Japanese, Chinese o Russian es un filtro de título/etiquetas, no una garantía de que cada región tenga resultados disponibles. No se eluden autenticación, suscripciones, DRM ni bloqueos geográficos.

## Categorías

La página **Categorías por estilo** usa una lista editorial de estilos y compara el texto con títulos, descripciones y etiquetas. El contador depende de los resultados que estén en el catálogo en ese momento; no representa el total global de cada sitio.

## Licencia y contenido

Verifica las condiciones de uso y licencias de cada proveedor antes de publicar una instancia. Esta aplicación debe usarse únicamente por personas adultas y con contenido legal.
