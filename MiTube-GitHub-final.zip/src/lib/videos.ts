import local from "@/data/videos.json";
import type { Video } from "@/types";
import { CACHE_HORAS } from "./config";

const LOCAL = local as unknown as Video[];
const CLAVE = "mitube-catalogo-v5";
const TTL = CACHE_HORAS * 60 * 60 * 1000;

let CATALOGO: Video[] | null = null;
let enCurso: Promise<void> | null = null;

function leerCache(): Video[] | null {
  try {
    const raw = localStorage.getItem(CLAVE);
    if (!raw) return null;
    const d = JSON.parse(raw);
    if (!d || Date.now() - d.t > TTL) return null;
    return d.v as Video[];
  } catch {
    return null;
  }
}

function guardarCache(v: Video[]) {
  try {
    localStorage.setItem(CLAVE, JSON.stringify({ t: Date.now(), v }));
  } catch {}
}

async function cargar() {
  const cache = leerCache();
  if (cache && cache.length) {
    CATALOGO = cache;
    return;
  }
  try {
    const r = await fetch("/api/videos");
    if (r.ok) {
      const d = await r.json();
      const remotos: Video[] = Array.isArray(d?.videos) ? d.videos : [];
      if (remotos.length) {
        const origenes = new Set(remotos.map((v) => v.origen));
        CATALOGO = [...remotos, ...LOCAL.filter((v) => !origenes.has(v.origen))];
        guardarCache(CATALOGO);
        return;
      }
    }
  } catch {}
  CATALOGO = LOCAL;
}

const CACHE_BUSQUEDAS = new Map<string, { paginas: Map<number, Video[]>; cargando: Map<number, Promise<Video[]>> }>();

async function buscarEnFuente(q: string, pagina: number): Promise<Video[]> {
  const termino = q.trim();
  if (termino.length < 2) return [];
  const clave = termino.toLocaleLowerCase();
  let cache = CACHE_BUSQUEDAS.get(clave);
  if (!cache) {
    cache = { paginas: new Map(), cargando: new Map() };
    CACHE_BUSQUEDAS.set(clave, cache);
  }
  const objetivo = Math.max(1, Math.min(5, pagina));
  for (let p = 1; p <= objetivo; p++) {
    if (cache.paginas.has(p)) continue;
    let tarea = cache.cargando.get(p);
    if (!tarea) {
      tarea = (async () => {
        try {
          const r = await fetch(`/api/videos?q=${encodeURIComponent(termino)}&page=${p}`);
          if (!r.ok) return [];
          const d = await r.json();
          return Array.isArray(d?.videos) ? (d.videos as Video[]) : [];
        } catch {
          return [];
        } finally {
          cache?.cargando.delete(p);
        }
      })();
      cache.cargando.set(p, tarea);
    }
    cache.paginas.set(p, await tarea);
  }
  const vistos = new Set<string>();
  return [...cache.paginas.entries()].sort(([a], [b]) => a - b).flatMap(([, videos]) => videos).filter((v) => {
    if (vistos.has(v.id)) return false;
    vistos.add(v.id);
    return true;
  });
}
export async function asegurar() {
  if (CATALOGO) return;
  if (!enCurso) enCurso = cargar();
  await enCurso;
}

export type Filtro = {
  fuente?: string;
  etiqueta?: string;
  q?: string;
  pagina?: number;
  porPagina?: number;
};

export async function listar(f: Filtro = {}) {
  await asegurar();
  const { pagina = 1, porPagina = 24, fuente, etiqueta, q } = f;
  let l = (CATALOGO ?? LOCAL).filter((v) => v.publicado !== false);
  if (q?.trim()) {
    const remotos = await buscarEnFuente(q, pagina);
    const combinados = [...remotos, ...l];
    const vistos = new Set<string>();
    l = combinados.filter((v) => {
      if (vistos.has(v.id)) return false;
      vistos.add(v.id);
      return v.publicado !== false;
    });
  }
  if (fuente) l = l.filter((v) => v.fuente.toLowerCase() === fuente.toLowerCase());
  if (etiqueta) {
    const normalizarEtiqueta = (s: string) => decodeURIComponent(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
    const etiquetaNormalizada = normalizarEtiqueta(etiqueta);
    l = l.filter((v) => (v.etiquetas ?? []).some((e) => normalizarEtiqueta(e) === etiquetaNormalizada) || normalizarEtiqueta(v.titulo ?? "").includes(etiquetaNormalizada) || normalizarEtiqueta(v.descripcion ?? "").includes(etiquetaNormalizada));
  }
  if (q?.trim()) {
    const normalizarTexto = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
    const t = normalizarTexto(q);
    l = l.filter((v) =>
      normalizarTexto(v.titulo ?? "").includes(t) ||
      (v.etiquetas ?? []).some((e) => normalizarTexto(e).includes(t)) ||
      normalizarTexto(v.fuente ?? "").includes(t) ||
      normalizarTexto(v.descripcion ?? "").includes(t)
    );
  }
  l = [...l].sort((a, b) => +new Date(b.fecha) - +new Date(a.fecha));
  const desde = (pagina - 1) * porPagina;
  return {
    items: l.slice(desde, desde + porPagina),
    total: l.length,
    hayMas: desde + porPagina < l.length,
  };
}

export async function porId(id: string): Promise<Video | null> {
  await asegurar();
  return (CATALOGO ?? LOCAL).find((v) => v.id === id) ?? null;
}

export async function relacionadas(v: Video, n = 12): Promise<Video[]> {
  const { items } = await listar({ porPagina: 600 });
  return items
    .filter((x) => x.id !== v.id)
    .map((x) => ({
      x,
      s:
        x.etiquetas.filter((e) => v.etiquetas.includes(e)).length +
        (x.fuente === v.fuente ? 0.5 : 0),
    }))
    .filter((o) => o.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, n)
    .map((o) => o.x);
}

export async function etiquetasPopulares(n = 24) {
  await asegurar();
  const c = new Map<string, number>();
  (CATALOGO ?? LOCAL).forEach((v) =>
    v.etiquetas.forEach((e) => c.set(e, (c.get(e) ?? 0) + 1))
  );
  return [...c.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([e]) => e);
}

export async function totalCatalogo() {
  await asegurar();
  return (CATALOGO ?? LOCAL).length;
}
