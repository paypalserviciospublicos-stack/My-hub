// Vídeos que no se pueden incrustar (el proveedor muestra "no se puede ver aquí").
// Se guardan en el navegador para que no vuelvan a aparecer en listados.
const CLAVE = "mitube-no-incrustables-v1";

function leer(): string[] {
  try {
    const d = JSON.parse(localStorage.getItem(CLAVE) ?? "[]");
    return Array.isArray(d) ? d : [];
  } catch {
    return [];
  }
}

export const bloqueados = (): Set<string> => new Set(leer());

export function bloquear(id: string) {
  try {
    const l = leer();
    if (!l.includes(id)) localStorage.setItem(CLAVE, JSON.stringify([...l, id].slice(-2000)));
  } catch {}
}

export async function esIncrustable(id: string): Promise<boolean> {
  if (!id.startsWith("ph-")) return true;
  try {
    const r = await fetch(`/api/embed?id=${encodeURIComponent(id)}`);
    if (!r.ok) return true;
    const d = await r.json();
    return d?.ok !== false;
  } catch {
    return true;
  }
}
