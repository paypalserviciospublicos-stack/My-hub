// Comprueba si un vídeo de Pornhub permite ser incrustado en otras webs.
// Si no lo permite, su iframe muestra "Este video no se puede ver aquí".
// Falla en abierto: ante cualquier duda (timeout, error de red, formato
// desconocido) responde ok:true para no ocultar vídeos que sí funcionan.
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const json = (ok: boolean, maxAge: number) =>
  new Response(JSON.stringify({ ok }), {
    headers: {
      "content-type": "application/json;charset=utf-8",
      "cache-control": `public, max-age=${maxAge}`,
    },
  });

export async function onRequestGet({ request }: any) {
  const url = new URL(request.url);
  const id = (url.searchParams.get("id") ?? "").replace(/^ph-/, "");
  if (!/^[a-zA-Z0-9]{3,40}$/.test(id)) return json(true, 60);

  try {
    const r = await fetch(
      "https://www.pornhub.com/webmasters/video_embed_code?id=" + encodeURIComponent(id),
      { headers: { "User-Agent": UA, Accept: "application/json" }, signal: AbortSignal.timeout(5000) }
    );
    if (!r.ok) return json(true, 60);
    const d: any = await r.json();
    const codigo = d?.embed?.code;
    if (typeof codigo === "string" && codigo.includes("iframe")) return json(true, 86400);
    // Respuesta de error explícita de la API (vídeo no incrustable o inexistente).
    if (d && typeof d === "object" && (d.code || d.message) && !d.embed) return json(false, 86400);
    return json(true, 60);
  } catch {
    return json(true, 60);
  }
}
