import { Helmet } from "react-helmet-async";
import FiltroFuentes from "@/components/FiltroFuentes";
import Sidebar from "@/components/Sidebar";
import VideoGrid from "@/components/VideoGrid";
import { SITE_NAME } from "@/lib/config";
import { Link } from "react-router-dom";
import TagPill from "@/components/TagPill";

const CATEGORIAS_ESTILO_INICIO = ["anal", "blowjob", "creampie", "oral", "amateur", "lesbian", "milf", "threesome", "japanese", "chinese", "russian", "pov"];

export default function Home() {
  return (
    <>
      <Helmet>
        <title>{SITE_NAME} - videos gratis</title>
        <meta name="description" content="Explora videos por fuente y categorías disponibles en el catálogo." />
      </Helmet>
      <FiltroFuentes />
      <section className="mt-6 rounded-2xl border border-[#262633] bg-[#111118] p-4 sm:p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">Categorías</h2>
            <p className="mt-1 text-xs text-[#8b8b96]">Explora el catálogo por etiquetas.</p>
          </div>
          <Link to="/categorias" className="shrink-0 text-sm font-medium text-[#ff2d78] hover:text-white">Ver todas →</Link>
        </div>
        <div className="flex flex-wrap gap-2">
          {CATEGORIAS_ESTILO_INICIO.map((c) => <TagPill key={c} etiqueta={c} />)}
        </div>
      </section>
      <div className="mt-6 flex gap-8">
        <div className="min-w-0 flex-1">
          <VideoGrid filtro={{}} />
        </div>
        <Sidebar />
      </div>
    </>
  );
}
