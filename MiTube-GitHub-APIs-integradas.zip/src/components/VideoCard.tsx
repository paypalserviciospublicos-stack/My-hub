import { useState } from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { fuentePorSlug } from "@/data/fuentes";
import { esFavorito, toggleFavorito } from "@/lib/storage";
import type { Video } from "@/types";

const dur = (s: number | null) =>
  s ? `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}` : null;

export default function VideoCard({ video }: { video: Video }) {
  const [fav, setFav] = useState(() => esFavorito(video.id));
  const [imagenRota, setImagenRota] = useState(false);
  const f = fuentePorSlug(video.fuente);

  return (
    <div className="group">
      <Link
        to={`/video/${video.id}`}
        className="relative block aspect-video overflow-hidden rounded-xl bg-[#14141c]"
      >
        {video.miniatura && !imagenRota ? (
          <img
            src={video.miniatura}
            alt={video.titulo}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImagenRota(true)}
            className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <span className="absolute inset-0 grid place-items-center bg-gradient-to-br from-[#24202b] via-[#15151d] to-[#0b0b0f]">
            <span className="grid h-12 w-12 place-items-center rounded-full border border-white/15 bg-black/30 text-white/80">▶</span>
          </span>
        )}
        {f && (
          <span
            className="absolute left-2 top-2 rounded-md px-2 py-0.5 text-[11px] font-medium text-black"
            style={{ background: f.color }}
          >
            {f.nombre}
          </span>
        )}
        {dur(video.duracion) && (
          <span className="absolute bottom-2 right-2 rounded bg-black/80 px-1.5 py-0.5 text-[11px] text-white">
            {dur(video.duracion)}
          </span>
        )}
      </Link>
      <div className="mt-2 flex items-start gap-2">
        <Link to={`/video/${video.id}`} className="min-w-0 flex-1">
          <h3 className="line-clamp-2 text-sm font-medium leading-snug">{video.titulo}</h3>
          <p className="mt-1 text-xs text-[#8b8b96]">{video.vistas.toLocaleString("es")} vistas</p>
        </Link>
        <button
          onClick={() => setFav(toggleFavorito(video))}
          aria-label="Favorito"
          className="shrink-0 rounded-md p-1.5 text-[#8b8b96] hover:text-[#ff2d78]"
        >
          <Heart className={`h-4 w-4 ${fav ? "fill-[#ff2d78] text-[#ff2d78]" : ""}`} />
        </button>
      </div>
    </div>
  );
}
