import type { Fuente } from "@/types";

// Solo mostramos fuentes que el backend intenta consultar directamente.
// No listar integraciones opcionales sin configurar: daban la impresión de
// que ya había vídeos disponibles en ellas.
export const FUENTES: Fuente[] = [
  { slug: "pornhub", nombre: "Pornhub", color: "#f96d00" },
  { slug: "eporner", nombre: "Eporner", color: "#f96d00" },
  { slug: "xvideos", nombre: "XVideos", color: "#d4132a" },
  { slug: "redtube", nombre: "RedTube", color: "#e30613" },
  { slug: "avgle", nombre: "Avgle · JAV", color: "#5b70c8" },
];

export const fuentePorSlug = (slug: string) => FUENTES.find((f) => f.slug === slug);
