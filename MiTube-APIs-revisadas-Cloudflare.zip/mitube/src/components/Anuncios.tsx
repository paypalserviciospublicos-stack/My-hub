import { useEffect } from "react";

export default function Anuncios() {
  useEffect(() => {
    const containerId = "container-55304d0b7ed5f1802470e7ad5504d8af";
    if (document.querySelector('script[data-biomanos-banner="true"]')) return;

    const script = document.createElement("script");
    script.async = true;
    script.setAttribute("data-cfasync", "false");
    script.dataset.biomanosBanner = "true";
    script.src = "https://biomanos.org/21/55304d0b7ed5f1802470e7ad5504d8af";

    const container = document.getElementById(containerId);
    if (container) container.appendChild(script);

    // Segundo anuncio solicitado por el usuario; cargarlo una sola vez.
    if (!document.querySelector('script[data-biomanos-second="true"]')) {
      const second = document.createElement("script");
      second.async = true;
      second.setAttribute("data-cfasync", "false");
      second.dataset.biomanosSecond = "true";
      second.src = "https://biomanos.org/14/d2fec92598553138dcb662e40df2e55c";
      document.body.appendChild(second);
    }
  }, []);

  return (
    <div className="my-5 flex min-h-0 w-full flex-col items-center overflow-hidden gap-4">
      <div id="container-55304d0b7ed5f1802470e7ad5504d8af" className="w-full max-w-full" />
    </div>
  );
}
