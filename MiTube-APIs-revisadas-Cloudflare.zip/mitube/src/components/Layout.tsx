import { Outlet } from "react-router-dom";
import Header from "./Header";
import Anuncios from "./Anuncios";
import ScrollToTop from "./ScrollToTop";

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#0b0b0f]">
      <ScrollToTop />
      <Header />
      <div className="mx-auto max-w-7xl px-4"><Anuncios /></div>
      <main className="mx-auto max-w-7xl px-4 py-6">
        <Outlet />
      </main>
      <footer className="mt-16 border-t border-[#1c1c26] py-8 text-center text-xs text-[#6b6b76]">
        Los videos se muestran mediante los reproductores originales de cada sitio.
      </footer>
    </div>
  );
}
