import type { Fuente } from "@/types";

export const FUENTES: Fuente[] = [
  { slug: "pornhub", nombre: "Pornhub", color: "#f96d00" },
  { slug: "eporner", nombre: "Eporner", color: "#6b8e23" },
  { slug: "xvideos", nombre: "XVideos", color: "#d4132a" },
  { slug: "xnxx", nombre: "XNXX", color: "#1a9c4b" },
  { slug: "youporn", nombre: "YouPorn", color: "#1a8fd1" },
  { slug: "redtube", nombre: "Redtube", color: "#e30613" },
  { slug: "spankbang", nombre: "SpankBang", color: "#ff9000" },
  { slug: "brazzers", nombre: "Brazzers", color: "#ffb400" },
  { slug: "realitykings", nombre: "Reality Kings", color: "#00a3e0" },
  { slug: "mofos", nombre: "Mofos", color: "#8e44ad" },
];

export const fuentePorSlug = (slug: string) => FUENTES.find((f) => f.slug === slug);
