const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const BUSQUEDAS = [
  // Consultas de catálogo público; no extraen ni desbloquean contenido de pago.
  "brazzers",
  "reality kings",
  "mofos",
  "digital playground",
  "blacked",
  "blacked raw",
  "loves anal",
  "culioneros",
  "fake taxi",
  "public agent",
  "milf hunter",
  "first anal quest",
  "amateur",
  "latina",
  "casting",
  "hd",
  "anal",
  "japanese",
  "japan",
  "asian",
  "chinese",
  "korean",
  "russian",
  "european",
  "blonde",
  "rubia",
  "yourporn",
  "purritan",
  "anal hd",
  "anal amateur",
  "anal latina",
  "anal japanese",
  "anal russian",
  "mature",
  "milf",
  "interracial",
  "verified amateur",
  "professional",
  "lesbian",
  "transgender",
  "reality",
  "interracial",
];

const cabeceras = { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9" };

function aSegundos(t: unknown): number | null {
  if (t === null || t === undefined || t === "") return null;
  const s = String(t);
  if (s.includes(":")) {
    const p = s.split(":").map((x) => parseInt(x, 10) || 0);
    return p.reduce((a, b) => a * 60 + b, 0);
  }
  const n = parseInt(s.replace(/\D/g, ""), 10);
  return isNaN(n) ? null : n;
}

function normalizar(v: any) {
  const id = v?.video_id;
  if (!id) return null;
  const etiquetas: string[] = [
    ...((v.tags ?? []) as any[]).map((t) => t?.tag_name),
    ...((v.categories ?? []) as any[]).map((c) => c?.category),
  ]
    .filter(Boolean)
    .map((s: string) => s.toLowerCase());

  return {
    id: "ph-" + id,
    fuente: "pornhub",
    origen: v.url ?? "https://www.pornhub.com/view_video.php?viewkey=" + id,
    embed_url: "https://www.pornhub.com/embed/" + id,
    titulo: v.title ?? "Sin titulo",
    descripcion: ((v.tags ?? []) as any[]).map((t) => t?.tag_name).filter(Boolean).join(", "),
    miniatura: v.thumb ?? v.default_thumb ?? "",
    duracion: aSegundos(v.duration),
    etiquetas: [...new Set(etiquetas)].slice(0, 8),
    vistas: parseInt(String(v.views ?? "0").replace(/\D/g, ""), 10) || 0,
    fecha: v.publish_date ?? new Date().toISOString(),
    publicado: true,
  };
}


function normalizarEporner(v: any) {
  if (!v?.id) return null;
  const etiquetas = String(v.keywords ?? "")
    .split(/[;,]/)
    .map((x: string) => x.trim().toLowerCase())
    .filter(Boolean);
  const miniatura = v.default_thumb?.src ?? v.default_thumb ?? v.thumb ?? "";
  return {
    id: "eporner-" + v.id,
    fuente: "eporner",
    origen: v.url ?? `https://www.eporner.com/hd-porn/${v.id}/`,
    embed_url: v.embed ?? `https://www.eporner.com/embed/${v.id}/`,
    titulo: v.title ?? "Sin título",
    descripcion: String(v.keywords ?? ""),
    miniatura,
    duracion: Number.isFinite(Number(v.length_sec)) ? Number(v.length_sec) : aSegundos(v.length_min),
    etiquetas: [...new Set(etiquetas)].slice(0, 20),
    vistas: Number(v.views ?? 0) || 0,
    fecha: v.added && !String(v.added).startsWith("1970") ? new Date(v.added.replace(" ", "T") + "Z").toISOString() : new Date().toISOString(),
    publicado: true,
  };
}

async function porTerminoEporner(term: string, page = 1) {
  try {
    const params = new URLSearchParams({ query: term || "all", per_page: "100", page: String(page), thumbsize: "big", order: "latest", format: "json" });
    const r = await fetch(`https://www.eporner.com/api/v2/video/search/?${params.toString()}`, { headers: { "Accept": "application/json" } });
    if (!r.ok) return [];
    const d: any = await r.json();
    return (Array.isArray(d?.videos) ? d.videos : []).map(normalizarEporner).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}

async function porTermino(term: string) {
  try {
    const r = await fetch(
      "https://www.pornhub.com/webmasters/search?search=" +
        encodeURIComponent(term) +
        "&thumb_size=medium",
      { headers: cabeceras }
    );
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr: any[] = d?.videos ?? d?.video ?? [];
    return arr.map(normalizar).filter(Boolean) as any[];
  } catch {
    return [] as any[];
  }
}

// Lustpress es un agregador open-source para varias webs, pero su playground público fue
// discontinuado. Solo se consulta si el administrador configura una instancia propia.
function normalizarLustpress(v: any, fuente: string) {
  const id = v?.id ?? v?.video_id;
  const titulo = v?.title ?? v?.titulo;
  const origen = v?.link ?? v?.url ?? v?.origin;
  if (!id || !titulo || !origen) return null;
  const tags = Array.isArray(v.tags) ? v.tags : Array.isArray(v.keywords) ? v.keywords : String(v.tags ?? v.keywords ?? "").split(/[;,]/);
  return {
    id: `lust-${fuente}-${id}`, fuente,
    origen, embed_url: v.embed ?? v.embed_url ?? origen,
    titulo, descripcion: String(v.description ?? v.descripcion ?? tags.join(", ")),
    miniatura: v.thumbnail ?? v.thumb ?? v.image ?? v.preview ?? "",
    duracion: aSegundos(v.duration ?? v.length),
    etiquetas: [...new Set(tags.map((x: any) => String(x?.name ?? x).trim().toLowerCase()).filter(Boolean))].slice(0, 20),
    vistas: Number(v.views ?? 0) || 0,
    fecha: v.uploaded ?? v.date ?? new Date().toISOString(), publicado: true,
  };
}

async function porTerminoLustpress(base: string, fuente: string, term: string) {
  try {
    const u = new URL(`/${fuente}/search`, base);
    u.searchParams.set("key", term || "all");
    u.searchParams.set("page", "1");
    const r = await fetch(u.toString(), { headers: { "Accept": "application/json", ...cabeceras } });
    if (!r.ok) return [];
    const d: any = await r.json();
    const arr = d?.data?.data ?? d?.data ?? d?.videos ?? [];
    return (Array.isArray(arr) ? arr : []).map((v: any) => normalizarLustpress(v, fuente)).filter(Boolean);
  } catch { return []; }
}

export async function onRequestGet({ request, env }: any) {
  const url = new URL(request.url);
  const termino = (url.searchParams.get("q") ?? "").trim().slice(0, 120);
  const cachePath = termino
    ? "/api/videos?q=" + encodeURIComponent(termino.toLowerCase())
    : "/api/videos";
  const cacheKey = new Request(url.origin + cachePath, { method: "GET" });

  try {
    const hit = await caches.default.match(cacheKey);
    if (hit) return hit;
  } catch {}

  // Si el visitante busca algo, consultamos ese término; la portada usa las búsquedas generales.
  const terminos = termino ? [termino] : BUSQUEDAS;
  // Limita concurrencia para no saturar la API pública ni agotar el tiempo de Cloudflare.
  const lotes: any[][] = [];
  for (let i = 0; i < terminos.length; i += 5) {
    const grupo = await Promise.all(terminos.slice(i, i + 5).map(porTermino));
    lotes.push(...grupo);
  }

  // Segunda fuente pública oficial: Eporner API v2. La portada consulta varias etiquetas
  // para ampliar el catálogo; las búsquedas del usuario consultan el término exacto.
  const terminosEporner = termino ? [termino] : ["all", "anal", "japanese", "asian", "russian", "blonde", "amateur", "latina", "rubia", "chinese", "korean", "milf", "lesbian", "latina amateur"];
  const epornerLotes: any[][] = [];
  for (let i = 0; i < terminosEporner.length; i += 4) {
    epornerLotes.push(...(await Promise.all(terminosEporner.slice(i, i + 4).map((t) => porTerminoEporner(t, 1)))));
  }

  // Si se configura LUSTPRESS_API_BASE con una instancia propia, suma resultados de
  // Xvideos, XNXX, YouPorn, RedTube, XHamster y Txxx sin depender de un demo discontinuado.
  const agregadorLotes: any[][] = [];
  const lustBase = String(env?.LUSTPRESS_API_BASE ?? "").trim();
  if (lustBase) {
    const sitios = ["xvideos", "xnxx", "youporn", "redtube", "xhamster", "txxx"];
    const q = termino || "anal";
    for (let i = 0; i < sitios.length; i += 3) {
      agregadorLotes.push(...(await Promise.all(sitios.slice(i, i + 3).map((site) => porTerminoLustpress(lustBase, site, q)))));
    }
  }

  const vistos = new Set<string>();
  const videos: any[] = [];
  for (const lote of [...lotes, ...epornerLotes, ...agregadorLotes]) {
    for (const v of lote) {
      if (!v || vistos.has(v.id)) continue;
      vistos.add(v.id);
      videos.push(v);
    }
  }
  videos.sort((a, b) => +new Date(b.fecha) - +new Date(a.fecha));

  const res = new Response(
    JSON.stringify({ videos, total: videos.length, generado: new Date().toISOString() }),
    {
      status: 200,
      headers: {
        "content-type": "application/json;charset=utf-8",
        "cache-control": "public, max-age=21600",
        "access-control-allow-origin": "*",
      },
    }
  );

  if (videos.length) {
    try {
      await caches.default.put(cacheKey, res.clone());
    } catch {}
  }

  return res;
}
