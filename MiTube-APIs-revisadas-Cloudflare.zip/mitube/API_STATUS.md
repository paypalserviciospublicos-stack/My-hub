# Estado de integraciones API de MiTube

Última revisión documental: 18 de octubre de 2026.

| Fuente | Estado en este ZIP | ¿Necesita servidor propio? | Observaciones |
|---|---|---:|---|
| Eporner API v2 | Integrada en `functions/api/videos.ts` | No | API oficial documentada, JSON, búsquedas y paginación. La disponibilidad de red debe comprobarse al desplegar. |
| Pornhub Webmaster search | Integración secundaria existente | No en el código actual | Endpoint sujeto a cambios, bloqueos y limitaciones; no se garantiza disponibilidad. |
| XVideos | No conectada automáticamente | Sí, si se usa Lustpress | No se encontró API oficial pública equivalente documentada. |
| XNXX | No conectada automáticamente | Sí, si se usa Lustpress | No se encontró API oficial pública equivalente documentada. |
| YouPorn | No conectada automáticamente | Sí, si se usa Lustpress | No se encontró API oficial pública equivalente documentada. |
| RedTube | No conectada automáticamente | Sí, si se usa Lustpress | No se encontró API oficial pública equivalente documentada. |
| XHamster | No conectada automáticamente | Sí, si se usa Lustpress | Integraciones comunitarias dependen del scraping y pueden romperse. |
| Txxx | No conectada automáticamente | Sí, si se usa Lustpress | No se encontró API oficial pública equivalente documentada. |

Referencias documentales:
- Eporner API v2: https://www.eporner.com/api/v2/
- Código y guía de Eporner: https://github.com/eporner/API
- Lustpress y aviso de discontinuación del playground público: https://github.com/sinkaroid/lustpress

No se afirma que las APIs hayan sido probadas en producción desde este entorno. El ZIP no depende de Lustpress para arrancar y mantiene los scripts publicitarios existentes.
