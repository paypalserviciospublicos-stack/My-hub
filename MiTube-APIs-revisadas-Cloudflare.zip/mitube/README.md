# MiTube

Aplicación React + Vite para explorar metadatos públicos de videos y abrirlos en los reproductores o páginas originales. No aloja ni desbloquea videos de terceros.

## Funciones

- Catálogo con búsqueda, filtros por fuente y etiquetas.
- Sección **Categorías** con buscador, recuento de resultados y enlaces a cada etiqueta.
- Carga progresiva de tarjetas desde el catálogo disponible.
- Favoritos e historial locales.
- Sin espacios publicitarios reservados; la integración publicitaria se añadirá después usando el código oficial de la red elegida.

## Cómo se obtienen los resultados

`functions/api/videos.ts` consulta el endpoint de búsqueda pública configurado y combina resultados de varios términos. La disponibilidad y el número de resultados dependen de la API de origen, sus límites, el contenido accesible desde la región y los cambios que haga el proveedor. No garantiza cientos de resultados ni consulta directamente los catálogos privados de estudios.

Para integrar catálogos de estudios de pago, utiliza sus API, feeds o enlaces de afiliado autorizados. La aplicación no debe intentar saltarse suscripciones, autenticación, DRM ni otras protecciones de acceso.

## Desarrollo

```sh
npm install
npm run dev
```

## Despliegue en Cloudflare Pages

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Configura Node.js 20 o superior para la compilación.
- La carpeta `functions/` contiene la función `/api/videos`.

## Ampliar categorías

Las categorías se derivan de las etiquetas devueltas por la fuente y de las etiquetas del catálogo local. Una etiqueta solo muestra recuentos basados en elementos existentes en el catálogo.

## APIs integradas y estado real

- **Eporner API v2 (documentada por el proveedor):** búsqueda JSON sin desplegar un servidor propio. Documentación oficial: https://www.eporner.com/api/v2/ y repositorio: https://github.com/eporner/API. Se usa desde `functions/api/videos.ts` mediante una función de Cloudflare Pages.
- **Pornhub Webmaster search (integración existente):** se consulta como fuente secundaria, pero el endpoint puede cambiar, limitar o bloquear solicitudes; su disponibilidad debe comprobarse una vez desplegado.
- **XVideos, XNXX, YouPorn, RedTube, XHamster y Txxx:** no se anuncian como APIs automáticas en esta versión. El agregador Lustpress ofrece conectores para esos sitios, pero su playground público fue discontinuado y el proyecto requiere desplegar una instancia propia. No se puede activar de forma fiable solo con subir este ZIP a Pages.

La API oficial de Eporner admite consultas como `all`, `anal`, `japanese`, `asian`, `russian`, `blonde` y `amateur`, y permite paginar resultados. La disponibilidad final depende de la respuesta del proveedor y de sus condiciones de uso. Las categorías se construyen a partir de etiquetas reales recibidas y del catálogo local; no se inventan resultados para fuentes sin conexión.

## Anuncios

Se conservan los dos scripts publicitarios facilitados por el propietario del proyecto en `src/components/Anuncios.tsx`. Su entrega y visualización dependen del proveedor de anuncios y de las políticas del navegador.

## Limitaciones de despliegue

Este ZIP no incluye credenciales privadas ni un servidor externo preinstalado. Cloudflare Pages despliega el frontend y la función `functions/api/videos.ts`; las fuentes sin API pública compatible no pueden habilitarse mágicamente desde el navegador.
